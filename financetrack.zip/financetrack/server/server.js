const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const transactionRoutes = require('./routes/transactionRoutes');

const app = express();

// Middleware for CORS and JSON parsing
app.use(cors());
app.use(express.json());

// Serve frontend files (optional for production build)
app.use(express.static(path.join(__dirname, 'public')));

// API routes
app.use('/api/transactions', transactionRoutes);

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/financetrack', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('✅ Connected to MongoDB successfully'))
  .catch((err) => console.error('Failed to connect to MongoDB', err));

const PORT = process.env.PORT || 5002;  // Ensure the port is available
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
