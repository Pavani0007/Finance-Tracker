document.addEventListener('DOMContentLoaded', () => {
  const totalBalanceEl = document.getElementById('total-balance');
  const transactionForm = document.getElementById('transaction-form');
  const transactionTable = document.getElementById('transaction-table');
  let totalBalance = 10000.00;  // Initial balance

  // Fetch and display transactions
  async function fetchTransactions() {
    try {
      const response = await fetch('http://localhost:5002/api/transactions');
      const transactions = await response.json();
      updateTransactionTable(transactions);
    } catch (error) {
      console.error('Error fetching transactions:', error);
    }
  }

  // Update table and balance
  function updateTransactionTable(transactions) {
    transactionTable.innerHTML = '';  // Clear existing rows
    totalBalance = 10000.00;          // Reset balance

    transactions.forEach((transaction) => {
      const amount = parseFloat(transaction.amount);

      if (transaction.Type === 'Expense' && amount > totalBalance) {
        // Skip adding the transaction if it exceeds the balance
        return;
      }

      if (transaction.Type === 'Expense') {
        totalBalance -= amount;
      } else {
        totalBalance += amount;
      }

      const date = new Date(transaction.date);
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${transaction.description}</td>
        <td>${transaction.Type === 'Expense' ? '-' : ''}$${amount.toFixed(2)}</td>
        <td>${transaction.Type}</td>
        <td>$${totalBalance.toFixed(2)}</td>
        <td>${!isNaN(date) ? date.toLocaleString() : 'Invalid Date'}</td>
      `;
      transactionTable.appendChild(row);
    });

    totalBalanceEl.textContent = totalBalance.toFixed(2);
  }

  // Handle form submission
  transactionForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const description = document.getElementById('description').value.trim();
    const amountInput = document.getElementById('amount').value;
    const type = document.getElementById('type').value;

    if (!description || !amountInput) {
      alert('Please fill in all fields.');
      return;
    }

    const amount = parseFloat(amountInput);
    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid amount.');
      return;
    }

    if (type === 'Expense' && amount > totalBalance) {
      alert('Expense exceeds current balance.');
      return;
    }

    const newTransaction = {
      description,
      amount,
      Type: type,
      date: new Date()
    };

    try {
      const response = await fetch('http://localhost:5002/api/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newTransaction),
      });

      if (response.ok) {
        fetchTransactions();
        transactionForm.reset();
      } else {
        try {
          const errorData = await response.json();
          alert(`Error adding transaction: ${errorData.error || 'Server error'}`);
        } catch {
          alert('Unexpected server response.');
        }
      }
    } catch (error) {
      console.error('Error adding transaction:', error);
      alert('Error adding transaction.');
    }
  });

  fetchTransactions();
});
